<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CartlistCountComponent extends Component
{
    public function render()
    {
        return view('livewire.cartlist-count-component');
    }
}
