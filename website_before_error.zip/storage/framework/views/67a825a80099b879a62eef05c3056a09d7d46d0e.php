<div>
    <h1>User Dashboard</h1>
    <p>Information relevant to the Customer will be displayed here.</p>
</div>
<?php /**PATH C:\Users\patel\OneDrive\Documents\GitHub\SOEN341_Project\ecommerce\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>