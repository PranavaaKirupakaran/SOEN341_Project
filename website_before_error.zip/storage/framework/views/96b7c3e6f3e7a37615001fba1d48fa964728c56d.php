<div>
    
</div>
<?php /**PATH C:\Users\patel\OneDrive\Documents\GitHub\SOEN341_Project\ecommerce\resources\views/livewire/seller/seller-add-product-component.blade.php ENDPATH**/ ?>