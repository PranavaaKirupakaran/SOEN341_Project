<div>
    <h1>Admin Dashboard</h1>
    <p>Information relevant to the Admin will be displayed here.</p>
</div>
<?php /**PATH C:\Users\patel\OneDrive\Documents\GitHub\SOEN341_Project\ecommerce\resources\views/livewire/admin/admin-dashboard-component.blade.php ENDPATH**/ ?>