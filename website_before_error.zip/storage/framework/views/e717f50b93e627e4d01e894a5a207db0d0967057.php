<div>
    <h1>Seller Dashboard</h1>
    <p>Information relevant to the Seller will be displayed here.</p>
</div>
<?php /**PATH C:\Users\patel\OneDrive\Documents\GitHub\SOEN341_Project\ecommerce\resources\views/livewire/seller/seller-dashboard-component.blade.php ENDPATH**/ ?>