<div>
    <h1>Admin Dashboard</h1>
    <p>Information relevant to the Admin will be displayed here.</p>
</div>
