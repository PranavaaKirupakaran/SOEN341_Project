<div>
    <h1>Seller Dashboard</h1>
    <p>Information relevant to the Seller will be displayed here.</p>
</div>
