<div>
    <h1>User Dashboard</h1>
    <p>Information relevant to the Customer will be displayed here.</p>
</div>
